import React from 'react'
import MyFilter from './MyFilter'

const WeddingPlanner = () => {
  return (
    <>
    
    
    <MyFilter title="Wedding Planners" category="Wedding Planner"/>

    
   </>
  )
}

export default WeddingPlanner