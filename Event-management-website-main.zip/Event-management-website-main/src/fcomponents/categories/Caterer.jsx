import React from 'react'
import MyFilter from './MyFilter'

const Caterer = () => {
  return (
    <>
    
    
    <MyFilter title="Food & Catering" category="Catering"/>
    
    </>
  )
}

export default Caterer