import React from 'react'
import MyFilter from './MyFilter'

const Photographer = () => {
  return (
    <>
    

    <MyFilter title="Photographers" category = "Photographer"/>

    
    </>
  )
}

export default Photographer