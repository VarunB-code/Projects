import React from 'react'
import MyFilter from './MyFilter'

export const SoundSystem = () => {
  return (
    <>
    
      <MyFilter title="Sound System" category="Sound System"/>
    
    </>
  )
}
