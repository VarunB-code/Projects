import React from 'react'
import MyFilter from './MyFilter'

const Functions = () => {
  return (
    <>
    <MyFilter title="Function Halls" category="Venue"/>
    
    </>
  )
}

export default Functions