import React from 'react'
import MyFilter from './MyFilter'

const Mehandi = () => {
    return (
        <>


            <MyFilter title="Mehandi Specialists" category="Mehandi" />




        </>
    )
}

export default Mehandi