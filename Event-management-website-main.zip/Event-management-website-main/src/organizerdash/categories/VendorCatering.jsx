import React from 'react'
import MyFilters from './MyFilters'

const VendorCatering = () => {
  return (
    <>
    
    
    <MyFilters title="Food & Catering" category="Catering"/>
    
    </>
  )
}

export default VendorCatering