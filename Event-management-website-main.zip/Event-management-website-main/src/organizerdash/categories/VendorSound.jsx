import React from 'react'
import MyFilters from './MyFilters'

const VendorSound = () => {
  return (
    <>
    <MyFilters title="Sound System" category="Sound System"/>
    
    </>
  )
}

export default VendorSound