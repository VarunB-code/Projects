import React from 'react'
import MyFilters from './MyFilters'

const VendorMehandi = () => {
  return (
    <>
    <MyFilters title="Mehandi Specialists" category="Mehandi"/>
    
    </>
  )
}

export default VendorMehandi