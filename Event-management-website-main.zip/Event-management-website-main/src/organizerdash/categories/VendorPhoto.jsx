import React from 'react'
import MyFilters from './MyFilters'

const VendorPhoto = () => {
  return (
    <>
    

    <MyFilters title="Photographers" category = "Photographer"/>

    
    </>
  )
}

export default VendorPhoto