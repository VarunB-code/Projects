import React from 'react'
import MyFilters from './MyFilters'

const VendorFunction = () => {
  return (
    <>
    <MyFilters title="Function Halls" category="Venue"/>
    
    </>
  )
}

export default VendorFunction