import React from 'react'
import MyFilters from './MyFilters'

const VendorWedding = () => {
  return (
    <>
    <MyFilters title="Wedding Planners" category="Wedding Planner"/>
    
    </>
  )
}

export default VendorWedding